package c343package;

/**
 * Created by mitja on 2017-05-28.
 */

public class HelloWorldTxt {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

}


