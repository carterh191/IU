package c343hello;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class MyCard implements Card {
    //Here List is used; but other data structure may be used;
    private List<String> cards = new ArrayList<String>();
    public MyCard() {
        initialize();
    }
    public void initialize() {
        String[] numbers = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        char[] shapes = {'S', 'C', 'H', 'D'};
        for (int i = 0; i < numbers.length; i ++) {
            for (int j = 0; j < shapes.length; j ++) {
                cards.add(numbers[i] + shapes[j]);
            }
        }
        System.out.println("deck ready with cards: " + cards.size());
    }
    //here the drawRandomCard() function returns a card randomly
    //students don't have to implement this function in this way
    public String drawRandomCard() {
        int n = cards.size();
        assert n > 0 : "empty deck";
        Random rand = new Random();
        int i = rand.nextInt(n);
        String s = cards.remove(i);
        return s;
    }
    //test client code moved to the MyGLSurfaceView class, in the onTouchEvent() method:
///*
//    public static void main(String[] argv) {
//        Card deck = new MyCard();
//        for(int i = 0; i < 5; i ++) {
//            String acard = deck.drawRandomCard();
//            System.out.println(i + " card: " + acard);
//        }
//    }
//*/
}
