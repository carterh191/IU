package c343hello;


public class Tweet {
    private String content;
    private String user;
    public Tweet(String user, String content) {
        this.user = user;
        this.content = content;
    }
    public void display() {
        System.out.println(user + " tweeted about " + content);
    }
    public boolean contains(String query) {
        return content.contains(query);
    }

    // test client code moved to the MyGLSurfaceView class, in the onTouchEvent() method:
// /*   public static void main(String[] argv) {
//        Tweet t = new Tweet("user1", "data science");
//        t.display();
//        String q = "data";
//        System.out.println("it is " + t.contains(q) + " that the tweet contains " + q);
//    }*/

}