package c343hello;

/** Mitja Hmeljak, CSCI Indiana University Bloomington, C343 Summer 2016
 *  integer 2D array implementation
 */



public class Int2DArray2 implements Int2DArray {
    private int[][] mat;
    private int rows;
    private int cols;

    /** 0. we could have a constructor.... */
    public Int2DArray2(int nrow, int ncol) {
        rows = nrow;
        cols = ncol;
        mat = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mat[i][j] = 0;
            }
        }
    }

    /** 1. .... or a "create" method. */
    public void create(int nrow, int ncol) {
        rows = nrow;
        cols = ncol;
        mat = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mat[i][j] = 0;
            }
        }
    }

    /** 2. Return the number of rows */
    public int numRow() {
        return rows;
    }
    /** 3. Return the number of columns */
    public int numCol() {
        return cols;
    }

    /** 4. Set the value to the cell specified by a row index and a column index */
    public void set(int rowidx, int colidx, int val) {
        mat[rowidx][colidx] = val;
    }

    /** 5. Get the value in a cell */
    public int get(int rowidx, int colidx) {
        return mat[rowidx][colidx];
    }

    /** 10. Clear (set to 0) all the elements of the array */
    public void clear() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mat[i][j] = 0;
            }
        }
    }
}