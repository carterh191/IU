public class BinNodeJr <E extends Comparable<?super E>>{ 
  private E value;
  private BinNodeJr<E> left;
  private BinNodeJr<E> right;
  public BinNodeJr(E e) {
    value = e;
    left = right = null;
  }
  public void setLeft(BinNodeJr<E> node) {
    left = node;
  }
 public void setRight(BinNodeJr<E> node) {
   right = node;
 }

public boolean find(E q){
  if (value.compareTo(q) == 0)
  { return true;
  } else{
    if ((this.left == null) && (this.right == null)){
    return false;
  } else if((this.left != null) && (this.right == null))
    return this.left.find (q);
  else return this.left.find(q)) || this.right.find(q));
}
}
}
 
 public static void main(String[] argv) {
     System.out.println("BinNodeJr test running...");
     // build a simple example tree:
     BinNodeJr<Character> root = new BinNodeJr<Character>('a');
     BinNodeJr<Character> node1 = new BinNodeJr<Character>('b');
     BinNodeJr<Character> node2 = new BinNodeJr<Character>('c');
     BinNodeJr<Character> node3 = new BinNodeJr<Character>('d');
     BinNodeJr<Character> node4 = new BinNodeJr<Character>('e');
     BinNodeJr<Character> node5 = new BinNodeJr<Character>('f');
     BinNodeJr<Character> node6 = new BinNodeJr<Character>('h');
     BinNodeJr<Character> node7 = new BinNodeJr<Character>('i');
     BinNodeJr<Character> node8 = new BinNodeJr<Character>('j');
     BinNodeJr<Character> node9 = new BinNodeJr<Character>('k');
     BinNodeJr<Character> node10 = new BinNodeJr<Character>('l');
     BinNodeJr<Character> node11= new BinNodeJr<Character>('m');
     root.setLeft(node1);
     root.setRight(node2);
     node1.setLeft(node2);
     node1.setRight(node3);
     node2.setLeft(node4);
     node2.setRight(node5);
     node3.setLeft(node6);
     node3.setRight(node7);
     node4.setLeft(node8);
     node4.setRight(node9);
     node5.setLeft(node10);
     node5.setRight(node11);    
  // find() needs to be implemented
     System.out.println(find);
     // find (40) should return true
//     System.out.println("is 100 in the tree? " + (find);
     // find (100) should return false
 }
}