class editDistance
{
  static int min(int x,int y,int z){
 
 for(i = 0; i <= m; i ++) d[i][0] = i;
for(j = 0; j <= n; j ++) d[0][j] = j; 
//fill the table:
for(i = 1; i <= m; i ++)  {
        for(j = 1; j <= n; j ++) {
                if(a[i] == b[j]) c = 0;
                else c = 1; 
                d[i][j] = min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1]+c);
        }
}
edit-distance = d[m][n]
  
  public static void main(String[] argv) throws FileNotFoundException {
  
  Scanner in = new Scanner(new FileReader(argv[0]));
  
  in.close();
}
}