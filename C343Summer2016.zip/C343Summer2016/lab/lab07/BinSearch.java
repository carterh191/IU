import java.util.*;

public class BinSearch <E extends Comparable<?super E>>{ 
  public int search(E[] arr, E q){
    int l = -1; 
    int r = arr.length;                           // l and r are beyond array bounds
    while (l+1!=r) {      // stop when l and r meet
        int i = (l+r)/2;                        // check middle of remaining subarray
        if (arr[i].compareTo(q) ==0) return i;   // found it
        else if (arr[i].compareTo(q) >0) r = i;          // in left half
        else l = i;                       // in right half
    }
    return arr.length;                  // search value not in A
}
  
  
  public static void main(String[] args)
  {
    BinSearch<Integer> bs = new BinSearch<Integer>();
    BinSearch<String> ar = new BinSearch<String>();
    BinSearch<Float> fl = new BinSearch<Float>();
    Integer[] a = {1,2,3,4,5,6};
    Float[] d = {1f, 5f, 3f, 2f, 9f};
    String[] b = {"a", "b", "c", "d", "e", "f"};
    
    System.out.println(bs.search(a, q));
  System.out.println(ar.search(b, q));
  System.out.println(fl.search(d, d));
  }
}
  