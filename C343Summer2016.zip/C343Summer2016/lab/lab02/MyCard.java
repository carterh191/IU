import java.util.Random;
import java.util.ArrayList;

public class MyCard implements Card {
  
  public void initialize(){
    
    private String[] deck = new String[52];
    private String[] suits = {"S", "H", "D", "C"};
    private String[] nums = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "k"};
    
      for (int i = 0; i < nums.length; i++) {
        for (int j = 0; j < suits.length; j++) {
          deck[suits.length*i + j] = nums[i]  + suits[j];
        }
      }
      public String drawRandomCard() {
        Random deck = new Random();
             int index = (int)(Math.random() * deck.length);
             int x = deck[i]; 
             deck[i] = deck[index]; 
             deck[index] = x; 
       }
       for (int i = 0; i < 1; i++){
             String suits = suits[deck[i];
             String nums = nums[deck[i];
             System.out.println(numbs + suits);
       }     
  }
}

   

        