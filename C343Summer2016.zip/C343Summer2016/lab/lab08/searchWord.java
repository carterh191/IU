
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.*;
import java.net.*;
import java.io.*;
import java.util.Scanner;      
import java.io.IOException;


public class WordSearch {
    public static void main(String[] args) throws Exception {
      

public class WordSearch {
   public static void main(String args[]) {
     
     Hashtable<String, String> hashtable = new Hashtable<String, String>();
     
     URL url = new URL("http://homes.soic.indiana.edu/classes/summer2016/csci/c343-mitja/2016/labs/lab08.txt");
Scanner in = new Scanner(url.openStream()); 
               while (in.hasNextLine()) {
                 String str = sc.nextLine();
                 String[] words = str split("\\s");
                        key = document_scanner.findInLine(words);                       
                        while (key != null) {
                                document_scanner.next();                
                                count ++;
                                key = document_scanner.findInLine(words);
                        }
                        document_scanner.nextLine();
                }
                        document_scanner.close();
                        System.out.println("Found Input "+ count + " times");
                   }
}