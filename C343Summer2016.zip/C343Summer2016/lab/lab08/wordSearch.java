import java.util.Hashtable;
import java.util.ArrayList;
import java.util.*;
import java.net.*;
import java.io.*;
import java.util.Scanner;      
import java.io.IOException;


public class WordSearch {
    public static void main(String[] args) throws Exception {
      

public class WordSearch {
   public static void main(String args[]) {
     
     Hashtable<String, String> hashtable = new Hashtable<String, String>();
     
     URL url = new URL("http://homes.soic.indiana.edu/classes/summer2016/csci/c343-mitja/2016/labs/lab08.txt");
Scanner in = new Scanner(url.openStream()); 

String key;
int count=0;

  while (in.hasNextLine()) {
        String str = sc.nextLine();
       String[] words = str split("\\s")
         for (i = 0, words) {
                  if (hashtable.containsKey(words[i])) {
                    ArrayList .ls;
                      ls.addLine);
                  else{
                    string = ls.addLine;
                    Hashtable.print(words), ls)
         

  
