import java.util.Hashtable;
import java.util.ArrayList;
import java.util.*;
import java.net.*;
import java.io.*;
import java.util.Scanner;      
import java.io.IOException;


public class BinSearch {
    public static void main(String[] args) throws Exception {
      
      Hashtable<String, ArrayList<Integer>> hashtable = new Hashtable<String, ArrayList<Integer>>();
      URL url = new URL("http://homes.soic.indiana.edu/classes/summer2016/csci/c343-mitja/2016/labs/lab08.txt");
      Scanner in = new Scanner(url.openStream());
      int lineNumber = 1;
   
               while (in.hasNextLine()){
                 String str = in.nextLine();
                 String[] words = str.split("s");
               }
               for (i = 0, i < words.length; i++){
                 if (hashtable.containsKey(words[i])){
                   Arraylist<Interger> arr = hashtable.get(words[i]);
                   if (!arr.contains(lineNumber)){
                     arr.add(lineNumber);
                   }
                   
                 } else{
                   ArrayList<Integer> ls = new ArrayList<Integer>();
                   ls.add(lineNumber);
                   hashtable.put(words[i], ls);
                 }
                     }
                     lineNumber++;
}
System.out.println("found"+ lineNumber + "times");
}

//not sure what I am doing wrong in my code