

public class Tweet {
  public String name;
  
  private String tweet;
  
  public void tweeter (String tweetName){
    name = tweetName;
  }
  private String firstName;
  public void setName (String name){
  firstName = name;
  }
  public void setTweet(String tweetTweet){
    tweet = tweetTweet;
  }
  
  public void printTweet(){
    System.out.println ("name: " + firstName);
    System.out.println("tweet: " + tweet);
  }
  
  public static void main(String args[]){
    Tweet tweetOne =new Tweet();
    tweetOne.setTweet("I just made a lot of money switching to Gieco");
    tweetOne.setName("Harrison");
    tweetOne.printTweet();
  }
}
  
    