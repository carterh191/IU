import java.util.ArrayList;
import java.util.Random;


public class RandomDNA {
  public static void main(String[] args) {
    ArrayList<Character>emptylist = new ArrayList<Character>();
    
    
    Random rand = new Random();
   
    for(int i = 0; i < 20; i++){
      int tempC = rand.nextInt(4);
      if(tempC == 0)
        emptylist.add('A');
      if(tempC == 1)
        emptylist.add('G');
      if(tempC == 2)
        emptylist.add('C');
      if(tempC == 3)
        emptylist.add('T');
 
     
    }
     System.out.println(emptylist);
  }
}
