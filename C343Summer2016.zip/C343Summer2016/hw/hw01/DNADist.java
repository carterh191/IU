import java.util.ArrayList;
import java.util.Random;


public class DNADist {
  public static void main(String[] args) {
    ArrayList<Character>l1 = new ArrayList<Character>();
       Random rand = new Random();
    for(int i = 0; i < 20; i++){
      int tempC = rand.nextInt(4);
      if(tempC == 0)
        l1.add('A');
      if(tempC == 1)
        l1.add('G');
      if(tempC == 2)
        l1.add('C');
      if(tempC == 3)
        l1.add('T');
     }
     System.out.println(l1);
  
  ArrayList<Character>l2 = new ArrayList<Character>();    
    for(int i = 0; i < 20; i++){
      int tempC = rand.nextInt(4);
      if(tempC == 0)
        l2.add('A');
      if(tempC == 1)
        l2.add('G');
      if(tempC == 2)
        l2.add('C');
      if(tempC == 3)
        l2.add('T');
  }
    System.out.println(l2);
  }
  int a = 0;{
    if (l1.length() != l2.length()) {
        return -1; 
    }
      for (int i = 0; i < l1.length(); i++) {
        if (l1.charAt(i) != l2.charAt(i)) {
            a++;
  }
    }
      return a;
}
}

