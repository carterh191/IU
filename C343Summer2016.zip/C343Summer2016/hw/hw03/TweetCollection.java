import java.net.*;
import java.io.*;
import java.util.Scanner;      
import java.io.IOException; 


public class TweetCollection {
    public static void main(String[] args) throws Exception {
      

public class TweetCollection {
   public static void main(String args[]) {
     
     URL url = new URL("http://homes.soic.indiana.edu/classes/summer2016/csci/c343-mitja/2016/homework/tweet-data-June29.txt");
Scanner in = new Scanner(url.openStream()); 
  while (in.hasNext()) {
        String str = in.nextLine();
        in.close();
}
      
  public void tweeter (String tweetName){
    name = tweetName;
  }
      
  
  private String firstName;
  public void setName (String name){
  firstName = name;
  }
  public void setTweet(String tweetTweet){
    tweet = tweetTweet;
  }
  
  public void printTweet(){
    System.out.println ("name: " + firstName);
    System.out.println("tweet: " + tweet);
  }
  
  public static void main(String args[]){
    Tweet tweetOne =new Tweet();
    tweetOne.setTweet("I just made a lot of money switching to Gieco");
    tweetOne.setName("Harrison");
    tweetOne.printTweet();
  }
   }
}
    }
}
 // String inputLine;
   //     while ((inputLine = in.readLine()) != null)
     //       System.out.println(inputLine);
