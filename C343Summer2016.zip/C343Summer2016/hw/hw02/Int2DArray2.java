import java.util.*;
import java.util.ArrayList;

public class Int2DArray2 {
  public static void main(String[] args) {
    List<int[]> rowList = new ArrayList<int[]>();
    
    rowList.add(new int[] { 1, 2, 3 });
    rowList.add(new int[] { 4, 5, 6 });
    
    for (int[] row : rowList) {
        System.out.println("Row = " + Arrays.toString(row));
    }}}