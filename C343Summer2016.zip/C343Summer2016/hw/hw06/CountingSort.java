import java.util.*;

  public class CountingSort{
  public int[] Count(int[] A) {
    int k =0;
      for (int i = 0; i < A.length; i++) {
        if(A[i]>k)
          k = A[i];
}
 //1st stage
int[] B = new int[k+1];
for (int i = 0; i < A.length; i++) {
     int atmp = A[i];
     B[atmp] += 1;
}

//second stage
int totalSoFar = 0;
for (int i = 1; i <= k; i++)
{
     int tmpCount = B[i];
     B[i] = totalSoFar;
     totalSoFar += tmpCount;
  }
  
  //3rd stage
  int[] C = new int[A.length];
for (int i = 0; i < A.length; i++) {
    int atmp = A[i];
    int outindex = B[atmp];
    C[outindex] = A[i];
    B[atmp] += 1;
}
return C;
  }

public static void main(String[] args){
    CountingSort s = new CountingSort();
    
    int[] a = {1,7,4,6, 7 , 2, 3, 5,6};
    int[] sort = s.Count(a);
    System.out.println(Arrays.toString(a));
    System.out.println(Arrays.toString(sort));
  }
}