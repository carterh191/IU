/**
 * TODO #1
 */

public class StringMatch {

  /**
   * TODO
   * 
   * Returns the result of running the naive algorithm to match pattern in text.
   */
	public static Result matchNaive(String pattern, String text) {  
		// return new Result(-1, 0);

		int m = pattern.length();
		int n = text.length();
		int i = 0, j = 0, comps = 0;
		while(i < m && j <= n - m + i) {
			if( pattern.charAt(i) == text.charAt(j)) {
				// result.add(i - pattern.length - 1);
				i++;
				j++;
				comps++;
			}
			else{
				comps++;
				j = j -1 + 1;
				i = 0;
			}
			if (i == m){
				return new Result(j - m, comps);
			}

		}
		return new Result(j-m, comps);
	}
  
  
  /**
   * TODO
   * Algorithm not finished
   * Populates flink with the failure links for the KMP machine associated with the
   * given pattern, and returns the cost in terms of the number of character comparisons.
   */
	public static int buildKMP(String pattern, int[] flink) {
		//return 0;
//		int j = 0;
//		flink[0] = -1;
//		flink[1] = 0;
//		int i = 2;
//		while(i <= m){
//			j = flink[i - 1];
//			//compute flink(i) based on earlier flinks
//			while(j != -1 && charAt.pattern(j) != charAt.pattern(i - 1)){
//				j = flink[i];
//				flink[i] = j + 1;
//
//			}
//		}

	int m = pattern.length();
    if(m == 0)
        return 0;
    flink[0] = -1;
    flink[1] = 0;
    int i = 2;
    int cn= 0;
    while(i <= m){
        int k = flink[i - 1];
        cn++;
      //compute flink(i) based on earlier flinks
        while(k != -1 && pattern.charAt(k) != pattern.charAt(i-1)){
            k = flink[k];
            cn++;
        }
        flink[i] = k++;
        i++;
    }
    return cn;
}
  
  
  /**
   * TODO
   * 
   * Returns the result of running the KMP machine specified by flink (built for the
   * given pattern) on the text.
   */
  public static Result runKMP(String pattern, String text, int[] flink) {
    //return new Result(-1, 0); 
	 int pl1 = pattern.length();
	 int pl2 = text.length();
	 
	 int flink1[] = new int[pl1];
	 int a = 0;
	 int b = 0;
	 
	 if(pattern.charAt(a) == text.charAt(b)){
		 a++;
		 b++;
	 }
	 if(a == pl1){
		 a = flink1[a-1];
	 }
	 else if(b < pl2 && pattern.charAt(a) != text.charAt(b)){
		 if (a != 0){
			 a = flink1[a-1];
		 }
		 else{
			 b = b+1;
		 }
	 }
	 return new Result(a, 0);
  }
  
  /**
   * Returns the result of running the KMP algorithm to match pattern in text. The number
   * of comparisons includes the cost of building the machine from the pattern.
   */
  public static Result matchKMP(String pattern, String text) {
    int m = pattern.length();
    int[] flink = new int[m + 1];
    int comps = buildKMP(pattern, flink);
    Result ans = runKMP(pattern, text, flink);
    return new Result(ans.pos, comps + ans.comps);
  }
  
  /**
   * TODO
   * 
   * Populates delta1 with the shift values associated with each character in the
   * alphabet. Assume delta1 is large enough to hold any ASCII value.
   */
  public static void buildDelta1(String pattern, int[] delta1) {
    delta1 = new int[127];
    
    for (int i = 0; i <= pattern.length(); i++){
    	int[] anArray = new int[delta1[pattern.charAt(i)]];
    }
  }

  /**
   * TODO
   * 
   * Returns the result of running the simplified Boyer-Moore algorithm using the
   * delta1 table from the pre-processing phase.
   */
  public static Result runBoyerMoore(String pattern, String text, int[] delta1) {
    return new Result(-1, 0);
     
  }
  
  /**
   * Returns the result of running the simplified Boyer-Moore algorithm to match 
   * pattern in text. 
   */
  public static Result matchBoyerMoore(String pattern, String text) {
    int[] delta1 = new int[Constants.SIGMA_SIZE];
    buildDelta1(pattern, delta1);
    return runBoyerMoore(pattern, text, delta1);
  }

}
