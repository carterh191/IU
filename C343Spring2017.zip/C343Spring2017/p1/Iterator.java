public interface Iterator {
  long[] next();
  boolean hasNext();
}
