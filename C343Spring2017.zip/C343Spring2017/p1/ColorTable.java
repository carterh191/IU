import java.awt.Color;
import java.util.Random;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.lang.RuntimeException;

/**
 * @author (Harrison Carter)
 * 
 * A ColorTable represents a dictionary of frequency counts, keyed on Color.
 * It is a simplification of Map<Color, Integer>. The size of the key space
 * can be reduced by limiting each Color to a certain number of bits per channel.
 */

/**
 * TODO
 * 
 * Implement this class, including whatever data members you need and all of the
 * public methods below. You may create any number of private methods if you find
 * them to be helpful. Replace all TODO comments with appropriate javadoc style 
 * comments. Be sure to document all data fields and helper methods you define.
 */

public class ColorTable {
	/**
	 * Counts the number of collisions during an operation.
	 */
	private static int numCollisions = 0;

	//private int getCountAt;
	private int bpc;
	//private int ic;
	private int cs;
	//private double rt;
	private int howFull;
	private long[][] gArray;

	/**
	 * Returns the number of collisions that occurred during the most recent get or
	 * put operation.
	 */
	public static int getNumCollisions() {
		return numCollisions;
	}

	/**
	 * TODO
	 * 
	 * Constructs a color table with a starting capacity of initialCapacity. Keys in
	 * the color key space are truncated to bitsPerChannel bits. The collision resolution
	 * strategy is specified by passing either Constants.LINEAR or Constants.QUADRATIC for
	 * the collisionStrategy parameter. The rehashThrehold specifies the maximum tolerable load 
	 * factor before triggering a rehash.
	 * 
	 * @throws RuntimeException if initialCapacity is not in the range [1..Constants.MAX_CAPACITY]
	 * @throws RuntimeException if bitsPerChannel is not in the range [1..8]
	 * @throws RuntimeException if collisionStrategy is not one of Constants.LINEAR or Constants.QUADRATIC
	 * @throws RuntimeException if rehashThreshold is not in the range (0.0..1.0] for a
	 *                             linear strategy or (0.0..0.5) for a quadratic strategy
	 */
	/**
	 * 
	 * @param initialCapacity throws exception if initialC is less than 1 and greater than max capacity
	 * @param bitsPerChannel throws exception if bpc is less than or equal to 1 or greater than 8 
	 * @param collisionStrategy throws exception is no linear or quadratic
	 * @param rehashThreshold throws exception from 2 different ranges.
	 * 
	 * 
	 */
	public ColorTable(int initialCapacity, int bitsPerChannel, int collisionStrategy, double rehashThreshold) { 

		if(initialCapacity < 1 || initialCapacity > Constants.MAX_CAPACITY)
			throw new RuntimeException("initialCapacity is not in the range [1..Constants.MAX_CAPACITY]");
		if(bitsPerChannel < 1 || bitsPerChannel > 8)
			throw new RuntimeException("bitsPerChannel is not in the range [1..8]");
		if(collisionStrategy != Constants.LINEAR && collisionStrategy != Constants.QUADRATIC)
			throw new RuntimeException("collisionStrategy is not one of Constants.LINEAR or Constants.QUADRATIC");
		if(collisionStrategy == Constants.LINEAR){
			if(rehashThreshold < 0.0 || rehashThreshold>1.0)
				throw new RuntimeException("rehashThreshold is not in the range (0.0..1.0] for linear strategy");
		}
		if(collisionStrategy == Constants.QUADRATIC){
			if(rehashThreshold < 0.0 || rehashThreshold>0.5)
				throw new RuntimeException("rehashThreshold is not in the range (0.0..0.5] for Quadratic strategy");
		}
		gArray = new long[2][initialCapacity];
	}


	/**
	 * TODO
	 * 
	 * Returns the number of bits per channel used by the colors in this table.
	 */
	/**
	 * 
	 * @return this function just returns the int getBitsPerChannel. I initialized it as bps
	 */
	public int getBitsPerChannel() {
		return bpc;
	}

	/**
	 * TODO
	 * 
	 * Returns the frequency count associated with color. Note that colors not
	 * explicitly represented in the table are assumed to be present with a
	 * count of zero. Uses Util.pack() as the hash function.
	 */
	/**
	 * 
	 * @param color My plan for this was to traverse my 2d array and compare the frequency of the array. I would 
	 * have a if statement that if the frequency wasn't in the array it would hash a 0 to the array.
	 * @return
	 */
	public long get(Color color){
		return 0;
	}

	/**
	 * TODO
	 * 
	 * Associates the count with the color in this table. Do nothing if count is less than
	 * or equal to zero. Uses Util.pack() as the hash function.
	 */
	public void put(Color color, long count) {



	}

	/**
	 * TODO
	 * 
	 * Increments the frequency count associated with color. Note that colors not
	 * explicitly represented in the table are assumed to be present with a
	 * count of zero.
	 */
	public void increment(Color color) {

	}

	/**
	 * TODO
	 * 
	 * Returns the load factor for this table.
	 */
	/**
	 * 
	 * @return the load factor is calculated by the size of the array and the capacity
	 */
	public double getLoadFactor() {
		return (getSize() / getCapacity());
	}


	/**
	 * 
	 * @return returns the internal array of the table
	 */
	/**
	 * 
	 * @return sets getCapacity as a private as this.cs
	 */
	public int getCapacity() {
		return this.cs;
	}

	/**
	 * TODO
	 * 
	 * Returns the number of key/value associations in this table.
	 */
	/**
	 * 
	 * @return Returns the number of key/value associations in this table
	 */
	public int getSize() {
		return howFull;
	}

	/**
	 * TODO
	 * 
	 * Returns true iff this table is empty.
	 */
	/**
	 * 
	 * @return returns a simple case if my howFull is equivalent to 0. If it
	 * is then it returns true otherwise false.
	 */
	public boolean isEmpty() {
		if (howFull == 0)
			return true;
		else
			return false;
	}


	/**
	 * TODO
	 * 
	 * Increases the size of the array to the smallest prime greater than double the 
	 * current size that is of the form 4j + 3, and then moves all the key/value 
	 * associations into the new array. 
	 * 
	 * Hints: 
	 * -- Make use of Util.isPrime().
	 * -- Multiplying a positive integer n by 2 could result in a negative number,
	 *    corresponding to integer overflow. You should detect this possibility and
	 *    crop the new size to Constants.MAX_CAPACITY.
	 * 
	 * @throws RuntimeException if the table is already at maximum capacity.
	 */
	private void rehash() { 

	}

	/**
	 * TODO
	 * 
	 * Returns an Iterator that marches through each color in the key color space and
	 * returns the sequence of frequency counts.
	 */
	/**
	 * 
	 * @return the iterator is suppose to first set int i = 0 at the start of the array. 
	 * If the next space has something in it then it is true, and otherwise false.
	 */
	public Iterator iterator() {
		Iterator iter = new Iterator() {
			private int i = 0;
			public boolean hasNext() {
				return i < gArray.length && gArray[i] != null;
			}
			public long[] next() {
				return gArray[i++];
			}
		};
		return iter;
	}

	/**
	 * TODO
	 * 
	 * Returns a String representation of this table.
	 */
	/**
	 * to string changes the strings in my Array to ints of 0 for each space.
	 */
	public String toString() {
		String aString;     
		aString = "";
		int column;
		int row;
		for (row = 0; row < gArray.length; row++) {
			for (column = 0; column < gArray[0].length; column++ ) {
				aString = aString + " " + gArray[row][column];
			}
			aString = aString + "\n";
		}

		return aString;
	}

	/**
	 * TODO
	 * 
	 * Returns the count in the table at index i in the array representing the table.
	 * The sole purpose of this function is to aid in writing the unit tests.
	 */
	/**
	 * 
	 * @param i Returns the count in the table at index i in the array representing the table.
	 * @return Wasn't able to get this right but what it is suppose to return the frequency at index I in the array
	 */
	public long getCountAt(int i) {
		return i; 
	//	return gArray[i];
	}
       
	/**
	 * Simple testing.
	 */
	public static void main(String[] args) {
		ColorTable table = new ColorTable(3, 6, Constants.QUADRATIC, .49);
		int[] data = new int[] { 32960, 4293315, 99011, 296390 };
		for (int i = 0; i < data.length; i++) 
			table.increment(new Color(data[i]));
		System.out.println("capacity: " + table.getCapacity()); // Expected: 7
		System.out.println("size: " + table.getSize());         // Expected: 3

		/* The following automatically calls table.toString().
       Notice that we only include non-zero counts in the String representation.

       Expected: [3:2096,2, 5:67632,1, 6:6257,1]

       This shows that there are 3 keys in the table. They are at positions 3, 5, and 6.
       Their color codes are 2096, 67632, and 6257. The code 2096 was incremented twice.
       You do not have to mimic this format exactly, but strive for something compact
       and readable.
		 */
		System.out.println(table);  
	}
}
