import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * TODO
 * 
 * Most of the work for this project involves implementing the connectAllWires()
 * method in this class. Feel free to create any helper methods that you deem
 * necessary.
 * 
 * Your goal is to come up with an efficient algorithm that will find a layout
 * that connects all the wires (if one exists) while attempting to minimize the
 * overall wire length.
 */

public class PathFinder {

	/**
	 * TODO
	 * 
	 * Lays out a path connecting each wire on the chip, and then returns a map
	 * that associates a wire id numbers to the paths corresponding to the
	 * connected wires on the grid. If it is not possible to connect the
	 * endpoints of a wire, then there should be no association for the wire id#
	 * in the result.
	 */
	/**
	 * 
	 * @param chip reads the chip using the buffer into a Hashmap
	 * @return goes through the hashmap looking for all the coords we and 
	 * gos to the first one we see. finds the closes neighbors and returns a sting of visited wires to connect them
	 */
	public static Map<Integer, Path> connectAllWires(Chip chip) {
		Map<Integer, Path> layout = new HashMap<Integer, Path>();

		Path que; //queue
		Map<Coord, Coord> visited; 	// Key = coordinate
									// value = parent

		for (Wire w : chip.wires) {
			que = new Path(w);
			visited = new HashMap<Coord, Coord>();
			visited.put(w.from, null);
			
			while (!que.isEmpty()) {
				Coord current = que.getFirst();
				if (current.equals(w.to)) {
					// finds coords we are looking for
					layout.put(w.wireId, backTrack(visited, w.to, w));
					break;
				}
				
				current = que.removeFirst();
				//System.out.println("Current: " + current.toString());

				for (Coord c : current.neighbors(chip.dim)) {
					if(!visited.containsKey(c) && chip.grid.get(c) != -1) {
						visited.put(c, current);
						que.add(c); //puts neighbors to queue
					}
				}
			}
		}

		return layout;
	}

	
	public static Path backTrack(Map<Coord, Coord> v, Coord to, Wire w) {
		LinkedList<Coord> coordsInReverse = new LinkedList<Coord>();
		
		Path p = new Path(w);
		Coord parent = to;
		while(parent != null) {
			coordsInReverse.add(parent);
			parent = v.get(parent);
		}
		
		//reverse 
		for(int i = coordsInReverse.size() - 2; i > -1; i--) {
			p.add(coordsInReverse.get(i));
		}
		return p;
	}
	/**
	 * TODO
	 * 
	 * Returns the sum of the lengths of all non-null paths in the given layout.
	 */
	/**
	 * 
	 * @param layout goes through the map starts at 0 and increase the count/length of the paths
	 * of the wires
	 * @return
	 */
	public static int totalWireUsage(Map<Integer, Path> layout) {
		int ans = 0;
		for(Integer wireId : layout.keySet()) {
			if(wireId != null)
				ans += layout.get(wireId).size();
		}
		
		return ans;
	}
}
