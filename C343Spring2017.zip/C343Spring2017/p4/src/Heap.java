import java.util.List;
import java.util.NoSuchElementException;
import java.util.Comparator;

/**
 * TODO: Complete the implementation of this class.
 * 
 * The keys in the heap must be stored in an array.
 * 
 * There may be duplicate keys in the heap.
 * 
 * The constructor takes an argument that specifies how objects in the 
 * heap are to be compared. This argument is a java.util.Comparator, 
 * which has a compare() method that has the same signature and behavior 
 * as the compareTo() method found in the Comparable interface. 
 * 
 * Here are some examples of a Comparator<String>:
 *    (s, t) -> s.compareTo(t);
 *    (s, t) -> t.length() - s.length();
 *    (s, t) -> t.toLowerCase().compareTo(s.toLowerCase());
 *    (s, t) -> s.length() <= 3 ? -1 : 1;  
 */

public class Heap<E> implements PriorityQueue<E> {
  protected List<E> keys;
  private Comparator<E> comparator;
  
  /**
   * TODO
   * 
   * Creates a heap whose elements are prioritized by the comparator.
   */
  public Heap(Comparator<E> comparator) {
    
  }

  /**
   * Returns the comparator on which the keys in this heap are prioritized.
   */
  @Override
public Comparator<E> comparator() {
    return comparator;
  }

  /**
   * TODO
   * 
   * Returns the top of this heap. This will be the highest priority key. 
   * @throws NoSuchElementException if the heap is empty.
   */
  @Override
public E peek() {
	  return null;
//    return a.get(0);
  }

  /**
   * TODO
   * 
   * Inserts the given key into this heap. Uses siftUp().
   */
  @Override
public void insert(E key) {

  }

  /**
   * TODO
   * 
   * Removes and returns the highest priority key in this heap.
   * @throws NoSuchElementException if the heap is empty.
   */
  @Override
public E delete() {
    return null;
  }

  /**
   * TODO
   * 
   * Restores the heap property by sifting the key at position p down
   * into the heap.
   */
  public void siftDown(int p) {
	/*  
	  int leftChildIndex, rightChildIndex, minIndex, temp, size = 0;
	  leftChildIndex = getLeft(p);
	  rightChildIndex = getRight(p);
	  if (rightChildIndex >= size){
		  if (leftChildIndex >= size)
			  return;
		  else
			  minIndex = leftChildIndex;
	  } else {
		  if (data[leftChildIndex] <= data[rightChildIndex])
			  minIndex = leftChildIndex;
		  else
			  minIndex = rightChildIndex;
	  }
	  if (data[p] > data[minIndex]){
		  temp = data[minIndex];
		  data[minIndex] = data[p];
		  data[p] = temp;
		  siftDown(minIndex);
	  }*/
  }
  
  /**
   * TODO
   * 
   * Restores the heap property by sifting the key at position q up
   * into the heap. (Used by insert()).
   */
  public void siftUp(int q) {
	  /*while (q != getParent && data[getParent(q)] < data[q]){
		  swap(data[getParent(q)], data[q]);
		  q = getParent(q);
	  }*/
  }
	  /*while(q > 0) {
          int p = getParent(q);
          if(((Key) hashMap[q].getKey()).compareTo((Key)hashMap[q].getKey()) < 0) {
              swap(null, p, q);
          }
          else break;
          q = p;
      }
}*/
  /**
   * TODO
   * 
   * Exchanges the elements in the heap at the given indices in keys.
   */
  public static void swap(int[] a, int i, int j) {
	  int temp = a[i];
	  a[i] = a[j];
	  a[j] = temp;
  }
  
  /**
   * Returns the number of keys in this heap.
   */
  @Override
public int size() {
    return keys.size();
  }

  /**
   * Returns a textual representation of this heap.
   */
  @Override
public String toString() {
    return keys.toString();
  }
  
  /**
   * TODO
   * 
   * Returns the index of the left child of p.
   */
  public static int getLeft(int p) {
	  return p * 2 + 1;
  }

  /**
   * TODO
   * 
   * Returns the index of the right child of p.
   */
  public static int getRight(int p) {
	  return getLeft(p) + 1;
  }

  /**
   * TODO
   * 
   * Returns the index of the parent of p.
   */
  public static int getParent(int p) {
	  return (p - 1) / 2;
  }
}
