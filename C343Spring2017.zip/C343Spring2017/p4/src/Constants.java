public class Constants {
  public static final String TITLE = "Project 4: Text Compression";
  
  public static final int BITESIZE = 8;
  
  public static final String ALICE = "alice-in-wonderland.txt";
  public static final String MOBY_DICK = "moby-dick.txt";
}
