import java.util.function.BiPredicate;

/**
 * TODO: This is your second major task.
 *
 * This class implements a generic height-balanced binary search tree, 
 * using the AVL algorithm. Beyond the constructor, only the insert()
 * method needs to be implemented. All other methods are unchanged.
 */

public class AVLTree<K> extends BinarySearchTree<K> {

	/**
	 * Creates an empty AVL tree as a BST organized according to the
	 * lessThan predicate.
	 */
	public AVLTree(BiPredicate<K, K> lessThan) {
		super(lessThan);
	}

	/**
	 * TODO
	 * 
	 * Inserts the given key into this AVL tree such that the ordering 
	 * property for a BST and the balancing property for an AVL tree are
	 * maintained.
	 */

	public Node insert(K key) {
		Node q = super.insert(key);

		if((Math.abs(root.left.height - root.left.height)) >= 2){
			LL(root);
			RR(root);
		}
		return q;
		//different of the height of right and left greater than or equal to 2
		//search for pivot
		//if no pivot then return
		//otherwise perform correct rotation
	}

	private Node LL(Node l){
		Node rootrightchild = root.right;
		root.right = rootrightchild.left;
		rootrightchild.left = root;

		root.height = Math.max(root.left.height, root.right.height) + 1;
		rootrightchild.height = Math.max(rootrightchild.right.height, rootrightchild.left.height) + 1;

		return rootrightchild;
	}

	private Node RR(Node R){
		Node rootleftchild = root.left;
		root.left = rootleftchild.right;
		rootleftchild.right = root;

		root.height = Math.max(root.left.height, root.right.height) + 1;
		rootleftchild.height = Math.max(rootleftchild.left.height, rootleftchild.right.height) + 1;

		return rootleftchild;
	}

}
