import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.BiPredicate;

/**
 * TODO: This is your first major task.
 * 
 * This class implements a generic unbalanced binary search tree (BST).
 */

public class BinarySearchTree<K> implements Tree<K> {

	/**
	 * A Node is a Location, which means that it can be the return value
	 * of a search on the tree.
	 */

	class Node implements Location<K> { 
		protected K data;
		protected Node left, right;
		protected Node parent;     // the parent of this node
		protected int height;      // the height of the subtree rooted at this node
		protected boolean dirty;   // true iff the key in this node has been removed

		/**
		 * Constructs a leaf node with the given key.
		 */
		public Node(K key) {
			this(key, null, null);
		}

		/**
		 * TODO
		 * 
		 * Constructs a new node with the given values for fields.
		 */
		/**
		 * 
		 * @param data constructs the node with K
		 * @param left contructs the left child node
		 * @param right constructs the right child node
		 */
		public Node(K data, Node left, Node right) {
			this.data = data;
			this.left = left;
			this.right = right;
			//new Node(this.data, this.left, this.right);
		}

		/**
		 * Return true iff this node is a leaf in the tree.
		 */
		protected boolean isLeaf() {
			return left == null && right == null;
		}

		/**
		 * TODO
		 * 
		 * Performs a local update on the height of this node. Assumes that the 
		 * heights in the child nodes are correct. This function *must* run in 
		 * O(1) time.
		 */
		/**
		 * check to see if the node is a leaf and if it is it adds one and keeps checking 
		 * through the right and left leafs to find max height
		 */
		protected void fixHeight() {
			//    	I check if "this" is a leaf, if it is, set height =1
			//    	check if this.left == null, if it is, set height = 1 + the height of right node
			//    	check if this.right == null, if it is,set height = 1 + the height of the left node.
			//    	else height equals to 1 + max value between left height and right height
			if(this.isLeaf()){
				int height = 1;
			}
			if (this.left == null){
				height = 1 + this.right.height;
			}
			if (this.right == null){
				height = 1 + this.left.height;
			} else {
				height = 1 + Math.max(this.right.height, this.left.height);
			}
		}

		/**
		 * TODO
		 * 
		 * Returns the data in this node.
		 */
		/**
		 * returns the data
		 */
		public K get() {
			return this.data;
		}


		/**
		 * TODO
		 * 
		 * Returns the location of the node containing the inorder predecessor
		 * of this node.
		 */
		/**
		 * gets ths nodes and left side of tree returns them inorder
		 */
		public Node getBefore() {
			Node n = this;
			if (n.left != null){
				return getMax(n.left);
			}
			Node p = n.parent;
			while (p != null && n == p.left){
				n = p;
				p = p.parent;
			}
			return p;
		}

		/**
		 * TODO
		 * 
		 * Returns the location of the node containing the inorder successor
		 * of this node.
		 */
		/**
		 * same as above but gets from the right side of the tree
		 */
		public Node getAfter() {
			Node n = this;
			if (n.right != null){
				return getMin(n.right);
			}
			Node p = n.parent;
			while (p != null && n == p.right){
				n = p;
				p = p.parent;
			}
			return p;
		}
	}
	
	public Node getMax(Node root){
		if(root.right == null){
			return root;
		} else{
			return getMax(root.right);
		}
	}
public Node getMin(Node root){
	if (root.left == null)
		return root;
	else{
		return getMin(root.left);
	}
}

	protected Node root;
	protected int n;
	protected BiPredicate<K, K> lessThan;

	/**
	 * Constructs an empty BST, where the data is to be organized according to
	 * the lessThan relation.
	 */
	public BinarySearchTree(BiPredicate<K, K> lessThan) {
		this.lessThan = lessThan;
	}

	/**
	 * TODO
	 * 
	 * Looks up the key in this tree and, if found, returns the (possibly dirty)
	 * location containing the key.
	 */
	/**
	 * uses a while loop to compare the key data in left and right to return the key in location of tree
	 */
	public Node search(K key) {
		Node head;
		head = root;
		while (head.data != key || head.isLeaf()){
			if (lessThan.test(head.left.data, key)){
				head = head.right;
			} else {
				head = head.left;
			}
		} 
		return head;
	} 

	/**
	 * TODO
	 * 
	 * Returns the height of this tree. Runs in O(1) time!
	 */
	/**
	 * uses a helper fucntion to run in O(1) time
	 * the root is height 1 and each leaf is height 0 from the root.
	 * iterates through the tree to find all the leafs and adds the left and right nodes to find height
	 */
	public int height() {
		return HelpHeigth(root);
//		if (root == null){
//			return 1;
//		} else {
//			int left = 0;
//			if (root.left != null){
//				//Want to iterate down the left to get height
//				//Do I need helper that takes nodes to do that?
//				//height is a attribute, but is height getting updated?
//				left = root.left.height;
//				//print left;
//			}
//			int right = 0;
//			if (root.right != null){			
//				right = root.right.height;
//			}
//			int meaHeight = Math.max(left,  right) + 1;
//			return meaHeight;
//		}
	}
	private int HelpHeigth(Node node){
		if (root == null)
			return 1;
		if (node.left == null && node.right == null)
			return 0;
		else
		return HelpHeigth(node.left) + HelpHeigth(node.right);
	}
	

	/**
	 * TODO
	 * 
	 * Clears all the keys from this tree. Runs in O(1) time!
	 */
	/**
	 * initializes the root as null and makes it 0
	 */
	public void clear() {
		root = null;
		n = 0;
	}

	/**
	 * Returns the number of keys in this tree.
	 */
	public int size() {
		Node current = null;
		if (current == null){
			return 0;
		}
		return (1 + size());
	}

	/**
	 * TODO
	 * 
	 * Inserts the given key into this BST, as a leaf, where the path
	 * to the leaf is determined by the predicate provided to the tree
	 * at construction time. The parent pointer of the new node and
	 * the heights in all node along the path to the root are adjusted
	 * accordingly.
	 * 
	 * Note: we assume that all keys are unique. Thus, if the given
	 * key is already present in the tree, nothing happens.
	 * 
	 * Returns the location where the insert occurred (i.e., the leaf
	 * node containing the key).
	 */
	/**
	 * uses helper function
	 * compares the key that you want ot insert and traverse the nodes in the tree to find where the 
	 * pointer needs to go and inserts key
	 */
	public Node insert(K key) {
		n++; 
		return root = insertHelper(key, root);   
	}

	private Node insertHelper(K key, Node p) {     
		if (p == null) 
			p = new Node(key);     
		else if (lessThan.test(key, p.data))      
			p.left = insertHelper(key, p.left);
		else if(p.dirty == true && key == p.data){
			p.dirty = false;
		}
		p.right = insertHelper(key, p.right);     
		return p;   
	}
	/**
	 * TODO
	 * 
	 * Returns true iff the given key is in this BST.
	 */
	/**
	 * checks to see if data is ni node. Uses helper function
	 */
	public boolean contains(K key) {
		//    Node p = search(key);
		//    return p != null;
		return containsHelper(key, root);
	}

	private boolean containsHelper(K key, Node p) {     
		if (p == null)       
			return false;     
		if (key == p.data)       
			return true;     
		if (lessThan.test(key, p.data))      
			return containsHelper(key, p.left);    
		return containsHelper(key, p.right);   
	}
	/**
	 * TODO
	 * 
	 * Removes the key from this BST. If the key is not in the tree,
	 * nothing happens. Implement the removal using lazy deletion.
	 */
	/**
	 * uses helper fuction to run faster
	 * traverses tree to remove key from node and fixes the tree
	 */
	public void remove(K key) {
		root = removeHelper(key, root);
	}

	private Node removeHelper(K key, Node p) {     
		if (p == null)       
			return p;     
		if (key == p.data) {       
			// Check for "easy delete" case.       
			if (p.left == null) {         
				n--;         
				return p.right;       
			}       
			else if (p.right == null) {        
				n--;         
				return p.left;       
			}       
			// Handle the replacement case.      
			p.data = minValue(p.right);      
			// At this point, p.data is in a leaf of p.right.       
			p.right = removeHelper(p.data, p.right);          
		}     
		else if (lessThan.test(key, p.data))       
			p.left = removeHelper(key, p.left);     
		else       
			p.right = removeHelper(key, p.right);    
		return p;   
	}

	private K minValue(Node p) {     
		assert p != null;     
		K minval = p.data;     
		while (p.left != null) {       
			minval = p.left.data;      
			p = p.left;     
		}     
		return minval;   
	}

	/**
	 * TODO
	 * 
	 * Clears out all dirty nodes from this BST.
	 * 
	 * Use the following algorithm:
	 * (1) Let ks be the list of keys in this tree. 
	 * (2) Clear this tree.
	 * (2) For each key in ks, insert it into this tree.
	 */
	/**
	 * uses an arraylist to build the tree and sets its node in a key 
	 */
	public void rebuild(){
		List<K> ks = new ArrayList<K>();
		ks = this.keys();
		clear();
		for (int i = 0; i < ks.size(); i++){
			this.insert(ks.get(i));
		}
		System.out.println(ks);
	}

	/**
	 * TODO
	 * 
	 * Returns a sorted list of all the keys in this tree.
	 */
	public List<K> keys() {
		List<K> ls = new LinkedList<>();
		Node r = root;
		kHelper(r, ls);
		return ls;
}
	
private List<K> kHelper(Node r, List<K> ls){
	if (r != null){
		if (r.dirty != true){
			ls.add(r.data);
			if (r.left != null){
				kHelper(r.left, ls);
			}
			if (r.right != null){
				kHelper(r.right, ls);
			}
		}
	}
	return ls;
}

	/**
	 * TODO
	 * 
	 * Returns a textual representation of this BST.
	 */
	public String toString(){
		StringBuilder string = new StringBuilder("[");
		helpToString(root, string);
		string.append("]");
		return string.toString();
	}

	private void helpToString(Node node, StringBuilder string){
		if ( node == null)
			return;

		if(node.left != null){
			helpToString(node.left, string);
			string.append(", ");
		}

		string.append(node.data);

		if (node.right != null){
			string.append(", ");
			helpToString(node.right, string);
		}
	}
}
