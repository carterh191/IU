/**
 * Tree interface and BinaryTree class from lec4b.
 */

public class BinaryTree implements Tree {
  
	/**
	 * 
	 * @param n Check the root node if it is null and doesn't have children 
	 * initialized left and right children as n.right/n.left, then we add 1 if there are child nodes
	 * @return it returns that max node of the left and right branch to get us the max height
	 */
	public int height(Node n){
		if (n == null)
			return 0;
		int left = height(n.left) + 1;
		int right = height(n.right) + 1;
		
		return Math.max(left,  right);
		
	}
  class Node {
    int data;
    Node left, right;
    
    Node(int key) {
      this(key, null, null);
    }
    
    Node(int data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }
    
    boolean isLeaf() {
      return left == null && right == null;
    }
  }
  
  Node root;
  int n;
  
  
  public void insert(int key) {
    n++;
    if (root == null)
      root = new Node(key);
    else if (root.left == null)
      root.left = new Node(key);
    else if (root.right == null)
      root.right = new Node(key);
    else if (Math.random() < 0.5)
      root = new Node(key, root, null);
    else
      root = new Node(key, null, root);
  }
  
  public boolean contains(int key) {
    return containsHelper(key, root);
  }
  
  /**
   * 
   * @param key is the key where it int is located
   * @param p is the node that contains helper get called on
   * @return this returns the bulk of the code after running the helper method
   */
  private boolean containsHelper(int key, Node p) {
    if (p == null)
      return false;
    if (p.data == key)
      return true;
    return containsHelper(key, p.left) || containsHelper(key, p.right);
  }
  
  public int size() {
    return n;
  }
  
  public static void main(String... args) {
    int[] a = new int[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    BinaryTree tr = new BinaryTree();
    assert tr.isEmpty();
    for (int key : a)
      tr.insert(key);
    assert tr.size() == a.length;
    assert !tr.root.isLeaf();
    for (int key : a)
      assert tr.contains(key);
    try { 
      tr.remove(3);
    }
    catch (UnsupportedOperationException e) {
    }  
    System.out.println("Passed all tests...");
    System.out.println(tr.height(tr.root));
  }
}

interface Tree {
  void insert(int key);
  default void remove(int key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(int key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
}

